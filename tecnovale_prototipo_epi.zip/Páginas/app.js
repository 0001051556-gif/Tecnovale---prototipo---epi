const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;'
}[c]));

const ymd = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const off = n => {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return ymd(d);
};
const dias = v => Math.round((new Date(v + 'T00:00:00') - new Date(ymd(new Date()) + 'T00:00:00')) / 864e5);
const fmt = v => v.split('-').reverse().join('/');

const COMP = ['A – Luvas e têxteis', 'B – Capacetes e plásticos', 'C – Calçados e outros'];
const TIPOS = { 'Luva': 0, 'Capacete': 1, 'Bota': 2, 'Óculos': 1, 'Protetor auricular': 2 };
const USERS = [
  { n: 'Ana Souza', p: 'Funcionário', l: 'ana' },
  { n: 'Rafael Dias', p: 'Responsável', l: 'rafael' },
  { n: 'Admin Demo', p: 'Administrador', l: 'admin' }
];
const KEY = 'tv-epi-v1';

function seed() {
  return {
    epis: [
      { codigo: 'EPI-0001', tipo: 'Luva', val: off(-10), sit: 'em uso' },
      { codigo: 'EPI-0002', tipo: 'Capacete', val: off(12), sit: 'em uso' },
      { codigo: 'EPI-0003', tipo: 'Bota', val: off(25), sit: 'em uso' },
      { codigo: 'EPI-0004', tipo: 'Óculos', val: off(90), sit: 'em uso' },
      { codigo: 'EPI-0005', tipo: 'Protetor auricular', val: off(200), sit: 'em uso' },
      { codigo: 'EPI-0006', tipo: 'Luva', val: off(-2), sit: 'em uso' }
    ],
    desc: [],
    niv: [35, 60, 20]
  };
}

let D;
try { D = JSON.parse(localStorage.getItem(KEY)); } catch (e) {}
if (!D) D = seed();

const save = () => {
  try { localStorage.setItem(KEY, JSON.stringify(D)); } catch (e) {}
};

let U = null, V = '', scan = null, led = -1, note = '', editing = null;

const sit = e => {
  if (e.sit === 'descartado') return ['Descartado', 't-m'];
  const d = dias(e.val);
  return d < 0 ? ['Vencido', 't-bad'] : d <= 30 ? ['Vence em ' + d + ' dias', 't-w'] : ['Válido', 't-ok'];
};

const tag = e => {
  const s = sit(e);
  return `<span class="tag ${s[1]}">${s[0]}</span>`;
};

const MENU = {
  'Funcionário': [['scan', 'Ler QR Code']],
  'Responsável': [['painel', 'Painel'], ['scan', 'Ler QR Code'], ['epis', 'EPIs'], ['hist', 'Histórico']],
  'Administrador': [['painel', 'Painel'], ['scan', 'Ler QR Code'], ['epis', 'EPIs'], ['hist', 'Histórico'], ['users', 'Usuários']]
};

function go(v) {
  if (!MENU[U.p].some(m => m[0] === v)) v = MENU[U.p][0][0];
  V = v;
  note = '';
  render();
}

function login(i) {
  U = USERS[i];
  go(MENU[U.p][0][0]);
}

function bins() {
  return `
    <div class="bins">
      ${COMP.map((c, i) => `
        <div class="bin">
          <div class="led ${led === i ? 'on' : ''}" title="LED"></div>
          <b>${esc(c)}</b>
          <div class="bar"><i class="${D.niv[i] >= 80 ? 'hi' : ''}" style="width:${D.niv[i]}%"></i></div>
          Nível: ${D.niv[i]}%
        </div>
      `).join('')}
    </div>
    <p class="mut">[Simulação] No protótipo físico, o ESP32 acende o LED e envia o nível por HTTP via Wi-Fi.</p>
  `;
}

function vLogin() {
  return `
    <main>
      <h1>Entrar no protótipo (Modo Teste)</h1>
      <div class="card">
        <p>Escolha um perfil de demonstração abaixo (dados fictícios):</p>
        <div class="chips">
          ${USERS.map((u, i) => `<button class="p" onclick="login(${i})">${u.p}: ${u.n}</button>`).join('')}
        </div>
      </div>
    </main>
  `;
}

function vPainel() {
  const a = D.epis.filter(e => e.sit !== 'descartado');
  const v = a.filter(e => dias(e.val) < 0);
  const p = a.filter(e => dias(e.val) >= 0 && dias(e.val) <= 30);

  return `
    <h1>Painel de Controle</h1>
    <div class="grid">
      <div class="kpi b"><strong>${v.length}</strong>EPIs vencidos</div>
      <div class="kpi w"><strong>${p.length}</strong>Vencem em até 30 dias</div>
      <div class="kpi o"><strong>${a.length - v.length - p.length}</strong>EPIs válidos</div>
      <div class="kpi"><strong>${D.desc.length}</strong>Descartes registrados</div>
    </div>

    <div class="card">
      <h2>Alertas de validade</h2>
      ${v.length + p.length ? `
        <div class="tw">
          <table>
            <tr><th>Código</th><th>Tipo</th><th>Validade</th><th>Situação</th></tr>
            ${[...v, ...p].map(e => `
              <tr>
                <td>${esc(e.codigo)}</td>
                <td>${esc(e.tipo)}</td>
                <td>${fmt(e.val)}</td>
                <td>${tag(e)}</td>
              </tr>
            `).join('')}
          </table>
        </div>
      ` : '<p class="mut">Nenhum EPI vencido ou próximo do vencimento.</p>'}
    </div>

    <div class="card">
      <h2>Lixeira: nível dos compartimentos</h2>
      ${bins()}
      <button class="s" onclick="sim()">Simular leitura do sensor</button>
    </div>
  `;
}

function sim() {
  D.niv = D.niv.map(n => Math.max(0, Math.min(100, n + Math.round(Math.random() * 30 - 10))));
  save();
  render();
}

function vScan() {
  let r = '';
  if (scan === 'x') {
    r = `<div class="msg e">Código não encontrado. Confira o QR Code ou escolha um exemplo.</div>`;
  } else if (scan) {
    const e = scan;
    const c = TIPOS[e.tipo] ?? 2;
    r = `
      <div class="card">
        <h2>${esc(e.codigo)}: ${esc(e.tipo)}</h2>
        <p>Validade: ${fmt(e.val)} ${tag(e)}</p>
        ${e.sit === 'descartado' ? '<p class="mut">Este EPI já foi descartado.</p>' : `
          <p>Orientação: descartar no compartimento <b>${esc(COMP[c])}</b>.</p>
          <div class="row">
            <div>
              <label for="mo">Motivo</label>
              <select id="mo">
                <option>Vencido</option>
                <option>Danificado</option>
                <option>Fim da vida útil</option>
                <option>Outro</option>
              </select>
            </div>
            <div>
              <label for="cp">Compartimento</label>
              <select id="cp">
                ${COMP.map((x, i) => `<option value="${i}" ${i === c ? 'selected' : ''}>${esc(x)}</option>`).join('')}
              </select>
            </div>
            <div>
              <label for="ds">Situação da destinação</label>
              <select id="ds">
                <option>Aguardando coleta</option>
                <option>Entregue à empresa coletora</option>
              </select>
            </div>
          </div>
          <p><button class="p" onclick="descartar()">Confirmar descarte</button></p>
        `}
      </div>
    `;
  }

  return `
    <h1>Ler QR Code</h1>
    <div class="card">
      <label for="qr">Código do EPI (digite ou clique num exemplo abaixo)</label>
      <div class="row">
        <input id="qr" placeholder="EPI-0001" onkeydown="if(event.key==='Enter')ler()">
        <button class="p" onclick="ler()">Consultar</button>
      </div>
      <div class="chips">
        ${D.epis.map(e => `<button class="s" onclick="ler('${e.codigo}')">${e.codigo}</button>`).join('')}
        <button class="s" onclick="ler('XXX-999')">Código inválido</button>
      </div>
    </div>
    ${note ? `<div class="msg k">${note}</div>` : ''}
    ${r}
    <div class="card">
      <h2>Status da Lixeira</h2>
      ${bins()}
    </div>
  `;
}

function ler(c) {
  c = (c || $('#qr').value).trim().toUpperCase();
  note = '';
  scan = D.epis.find(e => e.codigo === c) || 'x';
  render();
}

function descartar() {
  const c = +$('#cp').value;
  D.desc.unshift({
    epi: scan.codigo,
    tipo: scan.tipo,
    user: U.n,
    comp: c,
    mo: $('#mo').value,
    ds: $('#ds').value,
    dt: new Date().toLocaleString('pt-BR')
  });
  scan.sit = 'descartado';
  D.niv[c] = Math.min(100, D.niv[c] + 12);
  led = c;
  save();
  note = 'Descarte de ' + esc(scan.codigo) + ' registrado. LED do compartimento ' + esc(COMP[c]) + ' sinalizado.';
  scan = null;
  render();
}

function vEpis() {
  const e = editing;
  return `
    <h1>EPIs cadastrados</h1>
    <div class="card">
      <h2>${e ? 'Editar ' + esc(e.codigo) : 'Cadastrar EPI'}</h2>
      <div class="row">
        <div>
          <label for="tp">Tipo</label>
          <select id="tp">
            ${Object.keys(TIPOS).map(t => `<option ${e && e.tipo === t ? 'selected' : ''}>${t}</option>`).join('')}
          </select>
        </div>
        <div>
          <label for="cd">Código (QR Code)</label>
          <input id="cd" value="${e ? esc(e.codigo) : ''}" ${e ? 'readonly' : ''} placeholder="EPI-0007">
        </div>
        <div>
          <label for="vl">Data de validade</label>
          <input id="vl" type="date" value="${e ? e.val : ''}">
        </div>
      </div>
      ${note ? `<div class="msg e">${note}</div>` : ''}
      <p>
        <button class="p" onclick="salvar()">${e ? 'Salvar alterações' : 'Cadastrar EPI'}</button>
        ${e ? `<button class="s" onclick="editing=null;note='';render()">Cancelar</button>` : ''}
      </p>
    </div>

    <div class="card tw">
      <table>
        <tr><th>Código</th><th>Tipo</th><th>Validade</th><th>Situação</th><th>Ação</th></tr>
        ${D.epis.map((x, i) => `
          <tr>
            <td>${esc(x.codigo)}</td>
            <td>${esc(x.tipo)}</td>
            <td>${fmt(x.val)}</td>
            <td>${tag(x)}</td>
            <td><button class="s" onclick="editing=D.epis[${i}];note='';render()">Editar</button></td>
          </tr>
        `).join('')}
      </table>
    </div>
  `;
}

function salvar() {
  const cd = $('#cd').value.trim().toUpperCase();
  const vl = $('#vl').value;
  const tp = $('#tp').value;

  if (!/^[A-Z0-9-]{3,20}$/.test(cd) || !vl) {
    note = 'Informe um código válido (letras, números e hífen) e uma data de validade.';
    return render();
  }

  if (editing) {
    editing.tipo = tp;
    editing.val = vl;
  } else if (D.epis.some(x => x.codigo === cd)) {
    note = 'Já existe um EPI com este código.';
    return render();
  } else {
    D.epis.push({ codigo: cd, tipo: tp, val: vl, sit: 'em uso' });
  }

  editing = null;
  note = '';
  save();
  render();
}

function vHist() {
  return `
    <h1>Histórico de descartes</h1>
    <div class="card tw">
      ${D.desc.length ? `
        <table>
          <tr><th>Data</th><th>EPI</th><th>Motivo</th><th>Compartimento</th><th>Destinação</th><th>Registrado por</th></tr>
          ${D.desc.map(d => `
            <tr>
              <td>${esc(d.dt)}</td>
              <td>${esc(d.epi)} (${esc(d.tipo)})</td>
              <td>${esc(d.mo)}</td>
              <td>${esc(COMP[d.comp])}</td>
              <td>${esc(d.ds)}<br><span class="mut">Comprovante: pendente</span></td>
              <td>${esc(d.user)}</td>
            </tr>
          `).join('')}
        </table>
      ` : '<p class="mut">Nenhum descarte ainda. Use “Ler QR Code” para registrar o primeiro.</p>'}
    </div>
  `;
}

function vUsers() {
  return `
    <h1>Usuários</h1>
    <div class="card tw">
      <table>
        <tr><th>Nome</th><th>Login</th><th>Perfil</th></tr>
        ${USERS.map(u => `
          <tr>
            <td>${u.n}</td>
            <td>${u.l}</td>
            <td>${u.p}</td>
          </tr>
        `).join('')}
      </table>
    </div>
  `;
}

function reset() {
  D = seed();
  save();
  scan = null;
  led = -1;
  editing = null;
  note = '';
  render();
}

function render() {
  if (!U) {
    $('#app').innerHTML = `
      <header>
        <b>TecnoVale Sistemas [PROTÓTIPO]</b>
        <small>Controle e descarte de EPIs</small>
      </header>
      ${vLogin()}
    `;
    return;
  }

  const f = { painel: vPainel, scan: vScan, epis: vEpis, hist: vHist, users: vUsers }[V];
  $('#app').innerHTML = `
    <header>
      <div>
        <b>TecnoVale Sistemas [PROTÓTIPO]</b><br>
        <small>Controle e descarte de EPIs</small>
      </div>
      <div>
        ${esc(U.n)} (${U.p})
        <button class="s" onclick="U=null;render()">Sair</button>
      </div>
    </header>
    <nav aria-label="Menu">
      ${MENU[U.p].map(m => `<button class="${V === m[0] ? 'on' : ''}" onclick="go('${m[0]}')">${m[1]}</button>`).join('')}
    </nav>
    <main>${f()}</main>
    <footer class="mut">
      Ambiente de teste - Dados salvos localmente no navegador.
      <button class="s" onclick="reset()">Restaurar dados de exemplo</button>
    </footer>
  `;
}

render();
